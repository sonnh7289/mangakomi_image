import React from 'react';
import PropTypes from 'prop-types';

NotFound.propTypes = {
    
};

function NotFound(props) {
    return (
        <div>
           404 Not Found
        </div>
    );
}

export default NotFound;