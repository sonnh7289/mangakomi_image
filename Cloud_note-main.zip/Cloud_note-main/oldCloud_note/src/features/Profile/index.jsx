import React from "react";

function Profile(data) {
    return (
        <div>Nguyễn Tiến Lâm</div>
    )
}
export default Profile;